---
name: session-notes
user_invocable: true
description: "Generate markdown session notes from K_MIND near/far memory. Usage: /session-notes"
allowed-tools: Bash, Read
---

## /session-notes — Session Notes Generator

Generates structured markdown notes from the current session's K_MIND near and far memory files.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/session/session_notes.py'], capture_output=False)
sys.exit(result.returncode)
"`

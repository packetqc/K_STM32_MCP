---
name: checkpoint
user_invocable: true
description: "Crash/compaction recovery state persistence. Usage: /checkpoint [save|restore]"
allowed-tools: Bash, Read, Write
---

## /checkpoint — Recovery State Persistence

Save and restore checkpoint state for crash or compaction recovery. Persists current task progress so work can resume after interruption.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
result = subprocess.run(['python3', R+'/scripts/session/checkpoint.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

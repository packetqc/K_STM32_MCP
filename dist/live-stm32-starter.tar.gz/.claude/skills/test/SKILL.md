---
name: test
user_invocable: true
description: "Run targeted web page tests based on user request. Usage: /test <description of what to test>"
allowed-tools: Bash, Read, Write, Edit, Glob, Grep
---

## Prerequisites (Mandatory Gate — behav-020)

Before running any test, Claude MUST verify all tools are available. Do NOT proceed if any check fails — install first.

```bash
# Prerequisite gate — run before any test execution
python3 -c "
import subprocess, sys, os
errors = []
# 1. Chromium
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
sys.path.insert(0, R + '/scripts')
try:
    from render_web_page import find_chrome
    if not find_chrome(): errors.append('Chromium not found — run: python3 -m playwright install chromium')
except: errors.append('render_web_page.py not found — K_TOOLS module missing')
# 2. Playwright
try: import playwright
except: errors.append('Playwright not installed — run: pip install playwright && python3 -m playwright install chromium')
# 3. npm mermaid
if not os.path.exists('/tmp/mermaid-local-test/node_modules/mermaid/dist/mermaid.min.js'):
    errors.append('npm mermaid not found — run: mkdir -p /tmp/mermaid-local-test && cd /tmp/mermaid-local-test && npm init -y --silent && npm install mermaid')
if errors:
    print('PREREQUISITE GATE FAILED:')
    for e in errors: print(f'  ✗ {e}')
    sys.exit(1)
print('Prerequisites OK: Chromium, Playwright, npm mermaid')
"
```

**Rule**: If any prerequisite fails, install it before proceeding. If installation fails, STOP and report to the user. Never silently skip test execution.

## K_TOOLS — Web Test Engine v2.0

Arguments: $ARGUMENTS

### Core Principle: Test What Is Requested

There are **no predefined test modes**. Every test is driven by the user's specific request. Claude determines which pages and features to test based on what the user asks.

### Workflow

1. **Parse the user's request** — understand exactly what needs to be validated
2. **Identify target pages** — use data JSON files, codebase knowledge, or the user's explicit paths to determine which docs to test
3. **Construct targeted test command** — pass only the relevant pages to the engine
4. **Run the test** — produces results grid, GIF proof, MP4 proof, and results.json
5. **Generate the report** — assembles rich publication document
6. **Deliver** — output grid + proof artifacts + commit

### Page Discovery (utility, not automatic)

The engine provides `build_complete_tests()` as a discovery utility to enumerate all pages from data JSON files. Claude uses this to **find relevant pages** for the user's request — it is never run as a test mode itself.

Example: if the user says "test the modal popup fix", Claude identifies which pages use modals, then passes those specific paths to `--targets`.

### Step 1: Run Test Engine

**MANDATORY**: Capture the user's original request:
- `--request`: Your synthesized short description of what is being tested
- `--original-request`: The user's verbatim message that initiated this test

```bash
python3 Knowledge/K_TOOLS/scripts/web_test_engine.py \
    --targets <doc1.md> <doc2.md> ... \
    --request "<synthesized description>" \
    --original-request "<verbatim user prompt>"
```

For widget interaction tests on specific pages, add `--detailed`:
```bash
python3 Knowledge/K_TOOLS/scripts/web_test_engine.py \
    --targets <doc1.md> <doc2.md> \
    --detailed <doc1.md> <doc2.md> \
    --request "<description>" \
    --original-request "<verbatim>"
```

**After engine completes**: If `--request` and `--original-request` were not passed via CLI, Claude MUST update `results.json` to include both fields before generating the report.

### Step 2: Generate Report

After the test engine completes, generate the rich test report publication.
The report generator reads `request_text` and `original_request` from `results.json` automatically.

```bash
python3 Knowledge/K_TOOLS/scripts/generate_test_report.py \
    --title "<Descriptive Title Based on Request>" \
    --request "<synthesized description>" \
    --original-request "<verbatim user prompt>" \
    --gif Knowledge/K_TOOLS/test-reports/test-report.gif \
    --video Knowledge/K_TOOLS/test-reports/test-report.mp4 \
    --results Knowledge/K_TOOLS/test-reports/results.json \
    --slug test-main-navigator \
    -o docs/publications/test-main-navigator/
```

Note: `--request` and `--original-request` are optional if already stored in `results.json`.

### Step 3: Report Structure

The generated report follows this structure:

| Section | Content |
|---------|---------|
| **Introduction** | Test request (blockquote) + date |
| **Summary** | Pass/fail/skip totals table |
| **Proof GIF** | Animated GIF embedded inline (also used as webcard) |
| **Proof Video** | MP4 video embed with controls |
| **Pages Grid** | Per-page pass/fail table |
| **Detailed Grids** | Per-widget pass/fail tables (if detailed) |
| **Conclusion** | Auto-generated or custom assessment |

### Step 4: Deliver

After generating the report:
1. Show the results grid to the user
2. Show the proof GIF
3. Commit code + report + proof artifacts
4. Update data/tests.json if this is a new test entry

### TESTS Section

Test reports are published in the **TESTS** section of the main navigator left panel.
Section data: `docs/data/tests.json`
Publications: `docs/publications/test-<slug>/`

### Scripts Reference

| Script | Role |
|--------|------|
| `K_TOOLS/scripts/web_test_engine.py` | Test runner — DOM scan, widget trigger, proof capture |
| `K_TOOLS/scripts/generate_test_report.py` | Report generator — markdown publication from results |
| `K_TOOLS/scripts/generate_check_snapshot.py` | Check renderer — 3-part annotated proof images |
| `K_TOOLS/scripts/check_descriptions.json` | Progressive description registry — per-doc and per-phase |
| `K_TOOLS/scripts/render_web_page.py` | Page renderer — GIF/MP4 proof output |

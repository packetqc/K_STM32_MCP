---
name: mind-stats
user_invocable: true
description: "Show memory stats table — disk size, token counts, loaded context, and available tokens before compaction."
allowed-tools: Bash
---

## K_MIND — Memory Stats

!`python3 -c "
import subprocess, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
subprocess.run(['python3', R+'/scripts/memory_stats.py'])
"`

Output this table to the user. The first line shows the detected **context mode** (200K or 1M). The **Loaded** column shows tokens each store occupies in context. **Available** shows approximate tokens remaining before compaction. If WIP context has items, they are shown in a separate row. Context mode is detected from model ID suffix (`[1m]`) or `depth_config.json` → `context_mode` override.

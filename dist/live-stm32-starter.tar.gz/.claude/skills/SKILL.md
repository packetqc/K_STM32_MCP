---
name: beacon
user_invocable: true
description: "Live Network beacon — discovery and satellite synchronization. Usage: /beacon"
allowed-tools: Bash, Read
---

## /beacon — Live Network Beacon

Distributed knowledge network: beacon discovery and satellite synchronization.

### Execute

Claude scans for beacon signals from satellite repositories and reports network status.

### Protocol

1. Enumerate known satellites from modules.json
2. Check each satellite for beacon file (version, last sync, status)
3. Report network topology and sync state
4. Flag satellites with version drift or connectivity issues

---
name: concord
user_invocable: true
description: "Reference concordance — audit cross-references between scripts, skills, docs, routing, architecture. Usage: /concord [--fix|--check]"
allowed-tools: Bash, Read, Edit, Write
---

## /concord — Reference Concordance

**Update-first**: Audit cross-reference drift, then update all three documentation layers (system, user, mindmap). Complements `/normalize` (structure concordance).

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
result = subprocess.run(['python3', R+'/scripts/session/concord.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

### After Script Output

**Default mode** (`/concord` or `/concord --fix`): Read the audit report, then update ALL affected files across three layers:

1. **System docs**: CLAUDE.md, SKILL.md files, routing.json, conventions.json, documentation.json
2. **User docs**: commands.md, user-guide.md, command tables, publications
3. **Mindmap assets**: mind_memory.md work/convention nodes, architecture-mindmap.md

Re-run `concord.py --check` after updates to confirm zero drift.

**Check mode** (`/concord --check`): Report only, no updates.

### Concordance Checks (4 Active + 2 Delegated)

| # | Category | What It Checks |
|---|----------|---------------|
| C1 | Script Registry | Actual scripts vs listings in CLAUDE.md, SKILL.md, architecture-mindmap, routing |
| C2 | Command Names | Skill files vs conventions.json, commands.md, routing |
| C3 | Routing Completeness | routing.json scripts/skills vs actual files |
| C4 | Architecture Diagram | architecture-mindmap.md vs live mindmap programs node |
| C5 | Module Registration | Delegated to `/normalize` |
| C6 | Mindmap Work Nodes | Delegated to `/normalize` |

### When to Run

After adding scripts, renaming commands/skills, completing features, or importing modules. This is the **post-delivery sweep**.

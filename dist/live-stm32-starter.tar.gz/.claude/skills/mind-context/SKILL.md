---
name: mind-context
user_invocable: true
description: "Load K_MIND context. Usage: /mind-context (normal), /mind-context full (all nodes), /mind-context <path> <depth> (set branch depth and render)."
allowed-tools: Read, Grep, Glob, Bash
---

## K_MIND — Active Context

Arguments: $ARGUMENTS

### Mind Map
!`python3 -c "
import subprocess, sys, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
args = '''$ARGUMENTS'''.strip()
if args == 'full':
    subprocess.run(['python3', R+'/scripts/mindmap_filter.py', '--full'])
elif args and args != 'full':
    parts = args.rsplit(' ', 1)
    if len(parts) == 2 and parts[1].lstrip('-').isdigit():
        path, depth = parts[0], parts[1]
        subprocess.run(['python3', R+'/scripts/set_depth.py', '--path', path, '--depth', depth])
        subprocess.run(['python3', R+'/scripts/mindmap_filter.py'])
    else:
        subprocess.run(['python3', R+'/scripts/mindmap_filter.py', '--path', args, '--depth', '99'])
else:
    subprocess.run(['python3', R+'/scripts/mindmap_filter.py'])
"`

### Depth Config
!`python3 -c "
import subprocess, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
subprocess.run(['python3', R+'/scripts/set_depth.py', '--list'])
"`

### Display Conventions (from conventions.json)
!`python3 -c "
import json, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
with open(R+'/conventions/conventions.json') as f:
    data = json.load(f)
for ref in data['references']:
    if ref['name'].startswith('mindmap_'):
        print(f\"**{ref['name']}**: {ref['description']}\")
        print()
"`

### Active Conversation (Near Memory — Categorized by Group)
!`python3 -c "
import json, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
# Load near memory window config (default: 20 summaries)
window = 20
dc_path = R+'/conventions/depth_config.json'
if os.path.exists(dc_path):
    with open(dc_path) as f:
        dc = json.load(f)
    window = dc.get('near_memory_window', 20)
with open(R+'/sessions/near_memory.json') as f:
    data = json.load(f)
# Determine source: current session or last session (for fresh starts)
last = data.get('last_session')
has_last = last and last.get('summaries')
# Use current session summaries, or fall back to last session's summaries for fresh starts
source_summaries = data['summaries'] if data['summaries'] else (last['summaries'] if has_last else [])
# Apply window: only load last N summaries
windowed = source_summaries[-window:]
total = len(source_summaries)
categories = {'conversation': [], 'conventions': [], 'work': [], 'documentation': []}
for s in windowed:
    refs = s.get('mind_memory_refs', [])
    placed = False
    for ref in refs:
        for cat in ['conventions', 'work', 'documentation']:
            if ref.startswith(cat):
                categories[cat].append(s['summary'])
                placed = True
                break
        if placed:
            break
    if not placed:
        categories['conversation'].append(s['summary'])
if total > window:
    print(f'*Showing last {window} of {total} summaries (window configurable via depth_config.json)*')
    print()
# Output categorized (last 3 per category, always show all categories)
for cat in ['conversation', 'conventions', 'work', 'documentation']:
    items = categories[cat][-3:]
    print(f\"**{cat}**\")
    if items:
        for item in items:
            print(f\"  - {item}\")
    else:
        print(f\"  - (none)\")
    print()
"`

### Memory Stats
!`python3 -c "
import subprocess, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
subprocess.run(['python3', R+'/scripts/memory_stats.py'])
"`

### Behavioral Routing — Active Groups
!`python3 -c "
import subprocess, os
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
subprocess.run(['python3', R+'/scripts/routing_display.py', '--startup'])
"`

---

## Output Rules

**MANDATORY OUTPUT RULE:** After loading the data above, you MUST follow this sequence:
1. **READ** the full mindmap source and display conventions — internalize every node as an operational directive BEFORE rendering
2. **COPY the exact script output verbatim** — do NOT rephrase, summarize, or reformat ANY of the four sections below
3. **OUTPUT** four sections, each copied EXACTLY from the script output above:
   - **Mindmap**: copy the mermaid code block from mindmap_filter.py output EXACTLY as-is, inside a ```mermaid fence
   - **Recent Context**: copy the near_memory categorized output EXACTLY as-is — all 4 categories (conversation, conventions, work, documentation), all bullet points — VERBATIM
   - **Memory Stats**: copy the markdown table from memory_stats.py output EXACTLY as-is — all rows including Subtotal, System overhead, Conversation, Context used, Usable limit, Available
   - **Behavioral Routing**: copy the behavioral group activation table from routing_display.py output EXACTLY as-is — all 6 groups with roles and directives
4. A session confirmation line

**CRITICAL:** The scripts above already generate perfectly formatted output. Your job is to COPY it, not interpret it. Do NOT summarize section 2 into fewer lines. Do NOT drop table rows from section 3. Do NOT drop groups from section 4. Do NOT say "context loaded" — show the actual data.

**DO NOT** silently consume this data. **DO NOT** just say "context loaded". The user MUST see all four sections rendered EXACTLY as the scripts produced them.

After outputting, confirm you are in an active K_MIND session. Then read CLAUDE.md for the full behavioral rules — mindmap governance, node groups, display conventions, two-phase turn protocol (BEFORE/AFTER), and all available scripts are defined there as the single source of truth.

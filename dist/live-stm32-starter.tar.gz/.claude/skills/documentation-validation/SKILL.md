---
name: documentation-validation
user_invocable: true
description: "Validate documentation structure and integrity. Usage: /documentation-validation"
allowed-tools: Bash, Read
---

## /documentation-validation — Documentation Structure Validator

Validates the documentation structure for completeness and consistency.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/documentation_validation.py'], capture_output=False)
sys.exit(result.returncode)
"`

---
name: live-session
user_invocable: true
description: "Live session analysis — real-time clip monitoring, frame extraction, multi-stream. Usage: /live-session, I'm live, multi-live"
allowed-tools: Bash, Read, Write
---

## /live-session — Live Session Analysis

Real-time video analysis: clip monitoring, frame extraction, multi-stream, capture recipes.

### Commands

- `I'm live` — enter capture mode, pull clips, extract last frame, report
- `multi-live` — monitor multiple streams simultaneously
- `recipe` — print capture quick recipe (OBS + stream_capture.py params)

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
if not args:
    print('Usage: /live-session [capture|multi|recipe]')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/live/stream_capture.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

### Live Session Directives

1. No image prints — extract data via single-frame reads
2. Start from latest clip (highest number)
3. Fast 1-frame pulls — last frame of latest clip only
4. Focus on live troubleshooting
5. Proceed with live code modifications based on feedback
6. No waiting — report immediately, propose fixes

### Clip Naming Convention

```
live/dynamic/
  clip_0.mp4, clip_1.mp4, clip_2.mp4       # Primary: UI
  uart_0.mp4, uart_1.mp4, uart_2.mp4       # Secondary: Serial terminal
  cam_0.mp4,  cam_1.mp4,  cam_2.mp4        # Tertiary: Physical board camera
```

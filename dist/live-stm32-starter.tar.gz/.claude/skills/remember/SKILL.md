---
name: remember
user_invocable: true
description: "Store a note in session memory for future reference. Usage: /remember <note>"
allowed-tools: Bash, Read, Write
---

## /remember — Store Memory Note

Records a user note in K_MIND session memory (far_memory + near_memory) for future reference across sessions.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
args = '$ARGUMENTS'.strip()
if not args:
    print('Usage: /remember <note>')
    print('  Stores a note in session memory.')
    sys.exit(0)
result = subprocess.run([
    'python3', R+'/scripts/memory_append.py',
    '--role', 'user', '--content', args,
    '--role2', 'assistant', '--content2', 'Noted and stored in memory.',
    '--summary', 'User note: ' + args[:80]
], capture_output=False)
sys.exit(result.returncode)
"`

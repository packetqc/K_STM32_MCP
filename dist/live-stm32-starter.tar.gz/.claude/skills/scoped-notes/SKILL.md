---
name: scoped-notes
user_invocable: true
description: "Project-scoped notes and board items — #N: notes, methodologies, principles. Usage: #N: <content>"
allowed-tools: Bash, Read, Write
---

## /scoped-notes — Project-Scoped Notes

Add notes, methodologies, and principles scoped to a specific project.

### Commands

- `#N: <content>` — add scoped note to project P#N
- `#N:methodology:<topic>` — add methodology note
- `#N:principle:<topic>` — add principle note
- `#N:info` — show project scoped notes
- `#N:done` — mark project milestone complete

### Execute

Claude parses the `#N:` prefix to identify the target project, then records the note in the project's data file.

### Board Integration

- `g:<board>:<item>` — reference board item
- `g:<board>:<item>:done` — mark item done
- `g:<board>:<item>:progress` — update progress
- `g:<board>:<item>:info` — show item details

Board operations use GitHubHelper() for GitHub Projects v2 API access when elevated.

---
name: normalize
user_invocable: true
description: "Knowledge structure concordance — audit and fix EN/FR mirrors, front matter, webcards, links, assets. Usage: /normalize [--fix|--check]"
allowed-tools: Bash, Read, Edit, Write
---

## /normalize — Knowledge Structure Concordance

Audit and optionally fix the knowledge structure: EN/FR mirrors, front matter, webcards, links, assets, essential files.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
result = subprocess.run(['python3', R+'/scripts/session/normalize.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

### Modes

- **Audit** (`/normalize`): Report all issues, suggest fixes
- **Fix** (`/normalize --fix`): Apply fixes automatically
- **Check** (`/normalize --check`): Report only, exit with status code

### Concordance Checks (9 Categories)

| # | Category | What It Checks |
|---|----------|---------------|
| 1 | Structure | EN/FR mirrors, hub-subpage links |
| 2 | Layout | Front matter, OG tags, version banner |
| 3 | Webcards | 1200x630 animated GIF per page |
| 4 | Links | Cross-references consistent |
| 5 | Assets | Social preview, OG GIFs synced |
| 6 | Mindset | CLAUDE.md up to date |
| 7 | Branch | Default branch detection |
| 8 | Essential files | README, PLAN, LINKS, NEWS, CHANGELOG, VERSION |
| 9 | Projects folder | Flat .md files only |

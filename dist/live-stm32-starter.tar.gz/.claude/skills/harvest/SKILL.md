---
name: harvest
user_invocable: true
description: "Distributed knowledge harvesting — pull satellite insights, promote to core, healthcheck network. Usage: /harvest <subcommand>"
allowed-tools: Bash, Read, Edit, Write
---

## /harvest — Distributed Knowledge Harvesting

Pull knowledge from satellite projects, promote to core, healthcheck the network.

### Sub-commands

- `harvest <project>` — pull knowledge from satellite
- `harvest --list` — list harvested projects
- `harvest --procedure` — guided promotion walkthrough
- `harvest --healthcheck` — full network sweep
- `harvest --review <N>` — mark insight reviewed
- `harvest --stage <N> <type>` — stage for integration
- `harvest --promote <N>` — promote to core
- `harvest --auto <N>` — queue auto-promote
- `harvest --fix <project>` — update satellite CLAUDE.md

### Execute

Claude interprets the sub-command and executes the harvest protocol.

### Core Flow

1. Enumerate satellite branches via `git ls-remote`
2. Check cursors for incremental scan
3. Scan new content since last harvest
4. Version check (satellite vs core knowledge version)
5. Extract insights
6. Update dashboard files (source + EN docs + FR docs)
7. Regenerate webcards
8. Cleanup /tmp/

### Healthcheck

Full network sweep: scan core, crawl each satellite, update FR dashboard, process auto-promote queue, regenerate webcards, commit + PR.

### Promotion Pipeline

```
review -> stage -> promote -> auto
```

### Elevation

- Elevated: autonomous — commit + push + PR + merge
- Semi-auto: guide user through PR merge
- Requires GH_TOKEN for full autonomy

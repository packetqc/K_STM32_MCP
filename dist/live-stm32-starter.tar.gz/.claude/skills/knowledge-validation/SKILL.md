---
name: knowledge-validation
user_invocable: true
description: "Knowledge structure validation — audit knowledge data, publications, projects for completeness. Usage: /knowledge-validation"
allowed-tools: Bash, Read
---

## /knowledge-validation — Knowledge Structure Validation

Validates the knowledge data structure: publications, projects, documentation, profiles for completeness and consistency.

### Supporting Scripts

| Module | Script | Purpose |
|--------|--------|---------|
| K_VALIDATION | `scripts/documentation_validation.py` | Documentation structure cross-cut validation (D1/D2/D3) |
| K_PROJECTS | `scripts/compile_projects.py` | Project registry validation and compilation |

### Execute

Claude audits the knowledge structure systematically:
1. Publications: source exists, EN/FR docs (54 EN + 51 FR), webcards (112), front matter
2. Projects: P# registry, metadata files, board links (via `compile_projects.py`)
3. Documentation: all data JSON files valid, cross-references intact (via `documentation_validation.py`)
4. Profiles: all 8 files synchronized
5. Modules: all 6 K_* modules have conventions.json, documentation.json, work.json

### Severity Levels

- Pass: complete and consistent
- Minor: cosmetic issues only
- Moderate: missing optional elements
- Critical: structural issues requiring fix

---
name: resume
user_invocable: true
description: "Resume interrupted session from checkpoint — crash recovery and resiliency. Usage: /resume"
allowed-tools: Bash, Read, Write
---

## /resume — Session Recovery

Resume an interrupted session from checkpoint state. Restores todo list, git state, and protocol position.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/session/checkpoint.py', 'restore'], capture_output=False)
sys.exit(result.returncode)
"`

### Protocol

1. Read checkpoint state (K_TOOLS/scripts/session/checkpoint.py)
2. Verify git state matches checkpoint
3. Restore todo list from checkpoint
4. Restart protocol from last completed step
5. Auto-delete checkpoint on success

### Checkpoint-Aware Commands

These commands create checkpoints at step boundaries:
save, harvest, harvest --healthcheck, normalize --fix, pub new

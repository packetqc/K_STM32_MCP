---
name: know
user_invocable: true
description: "Display all available Knowledge commands organized by group. Usage: /know, /aide, /?"
allowed-tools: Bash, Read
---

## /know — Knowledge Command Reference

Displays the full command reference: all groups and commands with descriptions.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/help_command.py'], capture_output=False)
sys.exit(result.returncode)
"`

### Contextual Help

For contextual help on any command, use `<cmd> ?`:

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip()
if args and args.endswith('?'):
    cmd = args.rstrip('? ').strip()
    result = subprocess.run(['python3', R+'/scripts/help_contextual.py', cmd], capture_output=False)
    sys.exit(result.returncode)
"`

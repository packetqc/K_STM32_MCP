---
name: visual
user_invocable: true
description: "Generate visual evidence and diagrams via CLI. Usage: /visual <type> [options]"
allowed-tools: Bash, Read, Write
---

## /visual — Visual Evidence Generator

CLI tool for generating visual evidence, diagrams, and documentation visuals using the visual engine.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
if not args:
    print('Usage: /visual <type> [options]')
    print('  Generate visual evidence and diagrams.')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/visual_cli.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

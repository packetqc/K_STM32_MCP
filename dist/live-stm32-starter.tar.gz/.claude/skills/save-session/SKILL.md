---
name: save-session
user_invocable: true
description: "Full save protocol: commit, push, create PR, optionally merge. Usage: /save-session [--merge]"
allowed-tools: Bash, Read, Write
---

## /save-session — Session Save Protocol

Full save protocol: pre-save summary, commit all changes, push to remote, create PR via GitHubHelper, optionally merge.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
result = subprocess.run(['python3', R+'/scripts/session/save_session.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

### Notes

- Requires GH_TOKEN for PR creation
- Uses GitHubHelper() — no constructor args (Pitfall #23)
- `--merge` flag triggers auto-merge after PR creation

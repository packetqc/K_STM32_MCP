---
name: profile-update
user_invocable: true
description: "Refresh all 8 profile files with current stats — versions, publications, issues. Usage: /profile-update"
allowed-tools: Bash, Read, Edit, Write
---

## /profile-update — Profile Refresh

Refresh all 8 profile files (EN + FR, source + web tiers) with current stats.

### Execute

Claude reads current stats (knowledge version, publication count, project count) and updates all 8 profile files.

### Profile Files (8 total)

| File | Language | Format |
|------|----------|--------|
| profile/README.md | EN | Source |
| profile/README.fr.md | FR | Source |
| docs/profile/index.md | EN | Web (summary) |
| docs/fr/profile/index.md | FR | Web (summary) |
| docs/profile/resume/index.md | EN | Web (resume) |
| docs/fr/profile/resume/index.md | FR | Web (resume) |
| docs/profile/full/index.md | EN | Web (full) |
| docs/fr/profile/full/index.md | FR | Web (full) |

### Notes

- All 8 files must stay synchronized
- Never change biographical content without explicit user request

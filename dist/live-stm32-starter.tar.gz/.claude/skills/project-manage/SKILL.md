---
name: project-manage
user_invocable: true
description: "Project operations — list, info, register, review projects with GitHub board integration. Usage: /project-manage <subcommand>"
allowed-tools: Bash, Read, Edit, Write
---

## /project-manage — Project Management Operations

Project lifecycle operations: list, info, register, review.

### Sub-commands

- `project list` — list all projects with P# index, type, status
- `project info <P#>` — show full project details
- `project register <name>` — register with P# ID
- `project review <P#>` — review project state
- `project review --all` — review all projects

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
if not args:
    print('Usage: /project-manage <subcommand>')
    print('  list              — list all projects')
    print('  info <P#>         — show project details')
    print('  register <name>   — register new project')
    print('  review <P#>       — review project state')
    print('  review --all      — review all projects')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/compile_projects.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

### Project Types

- Core (P0): the knowledge system itself
- Child: repo-backed satellite projects
- Managed: projects within host repo

### Hierarchical Indexing

`P<n>/S<m>/D<k>` — Project / Story / Deliverable

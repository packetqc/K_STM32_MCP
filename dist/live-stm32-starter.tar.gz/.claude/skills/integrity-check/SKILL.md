---
name: integrity-check
user_invocable: true
description: "Knowledge system integrity check — validate modules, scripts, skills, mindmap concordance. Usage: /integrity-check"
allowed-tools: Bash, Read
---

## /integrity-check — System Integrity Check

Validates the Knowledge 2.0 system integrity: modules, scripts, skills, mindmap concordance, file structure.

### Execute

Claude performs a systematic check across all Knowledge modules:
1. Verify all modules in modules.json exist and have required structure
2. Check skills: every .claude/skills/ entry resolves to a valid SKILL.md
3. Verify scripts: all referenced scripts exist and are executable
4. Mindmap concordance: work nodes match actual state
5. Session integrity: far_memory/near_memory consistency

### Supporting Scripts

| Module | Script | Purpose |
|--------|--------|---------|
| K_VALIDATION | `scripts/documentation_validation.py` | Documentation structure cross-cut validation (D1/D2/D3) |
| K_TOOLS | `scripts/generate_check_snapshot.py` | Check validation framework and snapshot generation |

### Checks

| # | Category | What It Checks |
|---|----------|---------------|
| 1 | Modules | All 6 K_* modules exist with README, conventions, work |
| 2 | Skills | Every skill (42) has valid SKILL.md with required frontmatter |
| 3 | Scripts | All 75 scripts referenced by skills/routes are present |
| 4 | Mindmap | Work nodes match actual accomplished state (452-line grid) |
| 5 | Sessions | far_memory/near_memory ID consistency |
| 6 | Archives | Archive files referenced in far_memory exist |
| 7 | Routes | All 35 routes in routing.json resolve to valid methodologies/scripts |

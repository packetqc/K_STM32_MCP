---
name: render-web-page
user_invocable: true
description: "Render a web page from markdown source. Usage: /render-web-page <path>"
allowed-tools: Bash, Read, Write
---

## Prerequisites (Mandatory Gate — behav-020)

Before rendering, Claude MUST verify all tools are available. Do NOT proceed if any check fails — install first.

| Tool | Check | Install if missing |
|------|-------|--------------------|
| **Chromium** | `python3 -c "from scripts.render_web_page import find_chrome; assert find_chrome()"` | `python3 -m playwright install chromium` |
| **Playwright** | `python3 -c "import playwright"` | `pip install playwright && python3 -m playwright install chromium` |
| **npm mermaid** | `test -f /tmp/mermaid-local-test/node_modules/mermaid/dist/mermaid.min.js` | `mkdir -p /tmp/mermaid-local-test && cd /tmp/mermaid-local-test && npm init -y --silent && npm install mermaid` |

**Rule**: If any prerequisite is missing, install it. If installation fails, STOP and report to the user. Never silently skip rendering.

## /render-web-page — Web Page Renderer

Renders a web page from markdown source content into the docs viewer format.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
if not args:
    print('Usage: /render-web-page <path>')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/render_web_page.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

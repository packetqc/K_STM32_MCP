---
name: task-received
user_invocable: true
description: "Task intake — parse, classify, and route user requests to appropriate skills and protocols. Usage: /task-received <task>"
allowed-tools: Bash, Read
---

## /task-received — Task Intake & Routing

Parses and classifies user requests, routing them to the appropriate skill or protocol.

### Execute

Claude analyzes the incoming task:
1. Parse the request for command patterns (longest-match-first)
2. Classify: command, question, creative request, bug report
3. Route to appropriate skill or handle directly
4. Create todo list for multi-step tasks

### Routing Priority

1. Exact command match (e.g., `harvest --healthcheck`)
2. Command prefix match (e.g., `harvest`)
3. Natural language interpretation
4. Direct Claude handling

### Notes

- Commands.json defines the full routing table
- Longest-match-first prevents ambiguous routing
- Unknown commands fall through to Claude's natural handling

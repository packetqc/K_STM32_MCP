---
name: stream-capture
user_invocable: true
description: "Live session stream capture and clip management. Usage: /stream-capture [capture|discard]"
allowed-tools: Bash, Read, Write
---

## /stream-capture — Live Session Stream Tools

Capture and manage live session stream clips for documentation and evidence.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
action = args[0] if args else 'capture'
if action == 'discard':
    script = R+'/scripts/live/clip_discard.py'
else:
    script = R+'/scripts/live/stream_capture.py'
result = subprocess.run(['python3', script] + args[1:], capture_output=False)
sys.exit(result.returncode)
"`

### Actions

- `capture` (default): Start or manage stream capture
- `discard`: Discard the current clip

---
name: compile-projects
user_invocable: true
description: "Compile project data from source files into docs/data/projects.json. Usage: /compile-projects"
allowed-tools: Bash, Read
---

## /compile-projects — Project Data Compiler

Compiles project metadata from source files into the aggregated docs/data/projects.json for the web interface.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/compile_projects.py'], capture_output=False)
sys.exit(result.returncode)
"`

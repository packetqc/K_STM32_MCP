---
name: recall
user_invocable: true
description: "Search and recall archived memory across 4 layers: K_MIND, Git, GitHub, Deep. Usage: /recall <subject>"
allowed-tools: Bash, Read
---

## /recall — Memory Search & Recall

4-layer progressive memory search: K_MIND archives, git history, GitHub issues, deep archive scan.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip()
if not args:
    print('Usage: /recall <subject>')
    print('  Searches memory archives for the given subject keyword.')
    print()
    print('Examples:')
    print('  /recall architecture')
    print('  /recall theme')
    print('  /recall K_TOOLS')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/session/recall.py', '--subject', args], capture_output=False)
sys.exit(result.returncode)
"`

### Post-recall

After recall, Claude should:
1. Display the found memory context to the user
2. Use the recalled information to inform the current task

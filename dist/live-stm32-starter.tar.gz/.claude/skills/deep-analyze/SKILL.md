---
name: deep-analyze
user_invocable: true
description: "Deep video analysis — multi-frame extraction, subject detection, evidence reports. Usage: /deep <description>, /analyze <path>"
allowed-tools: Bash, Read, Write
---

## /deep-analyze — Deep Video Analysis

Extended video analysis beyond live session: multi-frame extraction, detection, evidence reports.

### Commands

- `deep <description>` — deep analysis of current live session with description context
- `analyze <path>` — analyze a specific video file

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip().split() if '$ARGUMENTS'.strip() else []
if not args:
    print('Usage:')
    print('  /deep-analyze deep <description>')
    print('  /deep-analyze analyze <path>')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/visual_cli.py'] + args, capture_output=False)
sys.exit(result.returncode)
"`

### Notes

- During `I'm live`, proactively suggest `deep` when detecting state inconsistencies
- Uses visual_engine.py for frame extraction and analysis

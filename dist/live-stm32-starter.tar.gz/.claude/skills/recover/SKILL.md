---
name: recover
user_invocable: true
description: "Scan for stranded work on claude/* and backup-* branches. Usage: /recover"
allowed-tools: Bash, Read
---

## /recover — Branch Recovery Scanner

Scans for stranded work on `claude/*` and `backup-*` branches that may contain unmerged changes. Checks PR status via GitHubHelper when GH_TOKEN is available.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/session/recover.py'], capture_output=False)
sys.exit(result.returncode)
"`

### Post-recover

After recovery scan, Claude should:
1. Present the list of recoverable branches with their status
2. Ask the user which branches to recover or clean up

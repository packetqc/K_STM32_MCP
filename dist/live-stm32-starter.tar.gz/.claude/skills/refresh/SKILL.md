---
name: refresh
user_invocable: true
description: "Reload K_MIND context — mindmap, summaries, and session state. Usage: /refresh"
allowed-tools: Bash, Read
---

## /refresh — Reload K_MIND Context

Reloads the mindmap, near/far memory summaries, and session state. Equivalent to re-running /mind-context.

### Execute

Invoke `/mind-context` to reload and display the full K_MIND context.

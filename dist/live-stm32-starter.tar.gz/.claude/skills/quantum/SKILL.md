---
name: quantum
user_invocable: true
description: "Cross-branch memory merge — import memory from a remote repository branch or legacy v1 archive. Usage: /quantum <repository> <branch> [--list|--dry|--full] OR /quantum legacy [--list|--dry|--category <cat>]"
allowed-tools: Bash, Read, Edit, Write
---

## Quantum — Cross-Branch Memory Merge

Merge K_MIND memory files from a remote repository branch into the current session without breaking local state. Far memory messages and near memory summaries are appended with remapped IDs. Archives are imported as distinct files. All imported entries are tagged with `quantum_source` for traceability.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip()
if not args:
    print('Usage: /quantum <repository> <branch> [--list|--dry|--full]')
    print('       /quantum legacy [--list|--dry|--category <cat>]')
    print()
    print('Examples:')
    print('  /quantum packetqc/knowledge claude/feature-x --list')
    print('  /quantum packetqc/knowledge claude/feature-x --dry')
    print('  /quantum packetqc/knowledge claude/feature-x')
    print('  /quantum packetqc/K_MIND main --list --full')
    print()
    print('Legacy import (v1 memory):')
    print('  /quantum legacy --list')
    print('  /quantum legacy --dry')
    print('  /quantum legacy')
    print('  /quantum legacy --category session-notes')
    print('  /quantum legacy --category minds')
    print('  /quantum legacy --category methodology')
    print('  /quantum legacy --category lessons-patterns')
    print('  /quantum legacy --category session-runtimes')
    print()
    print('Options:')
    print('  --list       List remote/legacy memory contents without merging')
    print('  --dry        Preview what would be imported (no writes)')
    print('  --full       Show full messages in list mode')
    print('  --category   Import only a specific legacy category')
    sys.exit(0)
parts = args.split()
if parts[0] == 'legacy':
    rest = parts[1:] if len(parts) > 1 else []
    result = subprocess.run(['python3', R+'/scripts/legacy_import.py'] + rest, capture_output=False)
else:
    result = subprocess.run(['python3', R+'/scripts/memory_quantum.py'] + parts, capture_output=False)
sys.exit(result.returncode)
"`

### Post-merge

After a successful merge (no `--list` or `--dry`), Claude should:
1. Output the merge results table to the user
2. Run `python3 Knowledge/K_MIND/scripts/memory_append.py` to record this quantum merge in the current session's memory
3. Update `mind/mind_memory.md` if new work items or conventions were imported

### Legacy Import

The `legacy` subcommand imports v1 memory from `Knowledge/legacy/` into K_MIND archives. All entries are tagged with `source: "legacy"` and `legacy_category` for traceability. Categories:

| Category | Source | Content |
|:---------|:-------|:--------|
| `session-notes` | `knowledge/data/notes/` | 63 session note markdown files (Feb-Mar 2026) |
| `minds` | `knowledge/data/minds/` | 7 mind/synthesis files |
| `methodology` | `knowledge/methodology/` | 63 methodology files |
| `lessons-patterns` | `knowledge/methodology/lessons+patterns/` | Lessons and embedded patterns |
| `session-runtimes` | `knowledge/state/sessions/` | 44 session runtime JSON files |

After legacy import, use `python3 scripts/memory_recall.py --subject legacy` to search imported memories.

---
name: status
user_invocable: true
description: "Show session status — memory stats, git state, active work items. Usage: /status"
allowed-tools: Bash, Read
---

## /status — Session Status

Displays current session status: memory stats, git branch state, active work items from mindmap.

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_MIND' if os.path.isdir('Knowledge/K_MIND/scripts') else '.'
result = subprocess.run(['python3', R+'/scripts/memory_stats.py'], capture_output=False)
sys.exit(result.returncode)
"`

### Post-status

After displaying stats, Claude should also check:
1. Current git branch and uncommitted changes
2. Active work items from mind_memory.md
3. Any pending checkpoints
4. WIP context state (if active): `python3 Knowledge/K_MIND/scripts/memory_append.py --wip show`
5. Context mode (200K/1M) is shown in the stats table header

---
name: project-create
user_invocable: true
description: "Create a new project with P# registration and GitHub Project board. Usage: /project-create <name>"
allowed-tools: Bash, Read, Write
---

## /project-create — Project Creation Protocol

Creates a new project with local P# registration, GitHub Project board (elevated), and web presence.

### Prerequisites

- GH_TOKEN available for GitHub board creation
- Uses GitHubHelper() — no constructor args

### Execute

!`python3 -c "
import subprocess, os, sys
R = 'Knowledge/K_TOOLS' if os.path.isdir('Knowledge/K_TOOLS/scripts') else '.'
args = '$ARGUMENTS'.strip()
if not args:
    print('Usage: /project-create <name>')
    print('  Creates project with P# index, GitHub board, and web pages.')
    sys.exit(0)
result = subprocess.run(['python3', R+'/scripts/project_create.py', '--name', args], capture_output=False)
sys.exit(result.returncode)
"`

### Protocol

1. Determine next P# index
2. Create project metadata file
3. Create GitHub Project board (elevated, via GitHubHelper)
4. Create web presence (EN + FR docs pages)
5. Progressive commits per step

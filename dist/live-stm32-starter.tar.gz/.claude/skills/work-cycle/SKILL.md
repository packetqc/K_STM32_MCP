---
name: work-cycle
user_invocable: true
description: "Work cycle management — track, commit, deliver work items with progressive commits. Usage: /work-cycle"
allowed-tools: Bash, Read, Edit, Write
---

## /work-cycle — Work Cycle Management

Manages the work lifecycle: track progress, progressive commits, delivery protocol.

### Execute

Claude manages the current work cycle:
1. Check active work items from mindmap
2. Track progress against todo list
3. Progressive commits per step (not batched)
4. Delivery: commit + push + PR when complete

### Protocol

- Each significant step gets its own commit
- Commit messages follow conventional commits format
- Work items updated in mindmap on completion
- Session memory updated with accomplished work

### Notes

- Integrates with /save-session for final delivery
- Integrates with /checkpoint for crash recovery

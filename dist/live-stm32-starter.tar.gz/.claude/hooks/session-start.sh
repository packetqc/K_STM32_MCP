#!/bin/bash
set -euo pipefail

# Read hook input from stdin
INPUT=$(cat)
SESSION_ID=$(echo "$INPUT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('session_id','unknown'))" 2>/dev/null || echo "unknown")
SOURCE=$(echo "$INPUT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('source','startup'))" 2>/dev/null || echo "startup")

cd "$CLAUDE_PROJECT_DIR"

# Detect K_MIND location: standalone (root) or imported (Knowledge/K_MIND/)
if [ -d "Knowledge/K_MIND/scripts" ]; then
    export K_MIND_ROOT="Knowledge/K_MIND"
else
    export K_MIND_ROOT="."
fi

# Install repo auto-memory files to Claude Code system (if newer or missing)
bash "$K_MIND_ROOT/scripts/install_memory.sh" 2>/dev/null || true

# Initialize session based on source
if [ "$SOURCE" = "startup" ]; then
    python3 "$K_MIND_ROOT/scripts/session_init.py" --session-id "$SESSION_ID" 2>&1
elif [ "$SOURCE" = "resume" ] || [ "$SOURCE" = "compact" ]; then
    python3 "$K_MIND_ROOT/scripts/session_init.py" --session-id "$SESSION_ID" --preserve-active 2>&1
fi

# Capture ephemeral artifacts (plans, etc.) before they're lost
python3 "$K_MIND_ROOT/scripts/capture_ephemeral.py" --plans 2>/dev/null || true

# Compute available tokens for lean startup output
AVAILABLE=$(python3 "$K_MIND_ROOT/scripts/memory_stats.py" --available 2>/dev/null || echo "unknown")

echo ""
echo "K_MIND_ROOT=$K_MIND_ROOT"
echo "K_MIND session initialized (source: $SOURCE, id: $SESSION_ID)."
echo ""
echo "MANDATORY: Output the following lean startup message to the user EXACTLY as shown below (preserve the markdown blockquote formatting), then wait for user input. Do NOT invoke /mind-context automatically. Do NOT add extra text or commentary."
echo ""
echo "---BEGIN STARTUP OUTPUT---"
echo "> [!NOTE]"
echo "> **K_MIND Started** — Available tokens: $AVAILABLE"
echo "> "
echo "> Quick reference commands:"
echo "> - \`/know\` — Knowledge command reference"
echo "> - \`/mind-context\` — Load mindmap and context"
echo "> - \`/mind-context full\` — Full mindmap with architecture/constraints"
echo "> - \`/mind-stats\` — Memory stats table"
echo "> - \`/validation\` — Engineering cycle assistance"
echo "> - \`/compact\` — Compact before heavy work"
echo "---END STARTUP OUTPUT---"
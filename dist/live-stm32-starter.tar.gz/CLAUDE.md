# Project Instructions

## Development — STM32 Configuration

- **Target MCU**: (e.g., STM32F411RE)
- **Clock**: (e.g., HSE 8MHz, PLL 100MHz)
- **Debug interface**: ST-Link V2 via OpenOCD
- **GDB port**: 3333
- **Build system**: (e.g., STM32CubeIDE, Makefile, CMake)
- **Flash procedure**: (e.g., `scripts/flash.bat`)

### Pin Assignments

| Pin | Function | Notes |
|-----|----------|-------|
| PA5 | LED | Onboard LED |

### Coding Standards

- (your conventions here)

## Project — Firmware Description

- **Purpose**: (what the firmware does)
- **Test procedures**: (how to verify)
- **Acceptance criteria**: (what "done" looks like)
